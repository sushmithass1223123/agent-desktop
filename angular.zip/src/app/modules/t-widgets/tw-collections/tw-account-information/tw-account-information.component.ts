import { Component, Input, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { FuseConfigService } from '@fuse/services/config.service';
import { AppDataService } from '@services/app-data.service';
import { TWidgetWrapper } from '@twidgets/utils/widget-wrapper/tw-wrapper';
import { ChartOptions } from 'chart.js';
import { takeUntil } from 'rxjs/operators';
import { CHART_COLORS } from 'app/constants';

@Component({
    selector: 'tw-account-information',
    templateUrl: './tw-account-information.component.html',
    styleUrls: ['./tw-account-information.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class TwAccountInformationComponent extends TWidgetWrapper implements OnInit, OnDestroy {
    // holds all the data related to this widget from the config
    @Input() data: any;

    maximized = false;

    wirelessData = [
        {
            data: [66, 34],
            labels: ['Download Sales', 'In-Store Sales', 'Mail-Order Sales'],
            options: {
                legend: { display: false },
                maintainAspectRatio: true,
                cutoutPercentage: 70,
                responsive: true
            },
            colors: [
                {
                    backgroundColor: ['rgba(196, 189, 231, 1)', 'lightgrey']
                }
            ]
        },
        {
            data: [50, 50],
            labels: ['Download Sales', 'In-Store Sales', 'Mail-Order Sales'],
            options: {
                legend: { display: false },
                maintainAspectRatio: true,
                cutoutPercentage: 70,
                responsive: true
            },
            colors: [
                {
                    backgroundColor: ['rgba(196, 189, 231, 1)', 'lightgrey']
                }
            ]
        }
    ];

    // -----------------------------------------------------------
    // @ [OPTIONAL] to store the fuse config for theme
    // -----------------------------------------------------------
    fuseConfig: any;

    // -----------------------------------------------------------
    // @ [OPTIONAL] to store entire app config and get update
    // -----------------------------------------------------------
    appConfig: any;

    /**
     * Constructor
     * @param {FuseConfigService} _fuseConfigService
     * @param {AppDataService} _appDataService
     */
    constructor(
        // @ [OPTIONAL]
        private _fuseConfigService: FuseConfigService,
        // @ [OPTIONAL]
        private _appDataService: AppDataService
    ) {
        super();
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * A callback method that is invoked immediately after the default change detector has checked the directive's data-bound properties for the first time,
     * and before any of the view or content children have been checked. It is invoked only once when the directive is instantiated.
     */
    ngOnInit(): void {
        // call the wrapper init method
        this.initWrapper(this.data);
        // -----------------------------------------------------------
        // @ [OPTIONAL] to get the fuse config
        // -----------------------------------------------------------
        this._fuseConfigService.config.pipe(takeUntil(this.unsubscribeAll)).subscribe((config: any) => {
            this.fuseConfig = config;
        });

        // -----------------------------------------------------------
        // @ [OPTIONAL] to get the app config
        // -----------------------------------------------------------
        this._appDataService.config.pipe(takeUntil(this.unsubscribeAll)).subscribe((config: any) => {
            this.appConfig = config;
        });
    }

    /**
     * A callback method that performs custom clean-up, invoked immediately before a directive, pipe, or service instance is destroyed.
     */
    ngOnDestroy(): void {
        // call the wrapper destroy method
        this.destroyWrapper();
    }

    // -----------------------------------------------------------------------------------------------------
    // @  Private Methods
    // -----------------------------------------------------------------------------------------------------

    // -----------------------------------------------------------------------------------------------------
    // @  Public Methods
    // -----------------------------------------------------------------------------------------------------
}

// for more info visit - https://angular.io/api/core
