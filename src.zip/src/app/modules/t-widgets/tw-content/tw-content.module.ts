import { NgModule } from '@angular/core';
import { SharedModule } from '@modules/shared/shared.module';
import { TwTemplateModule } from 'app/modules/t-widgets/tw-template/tw-template.module';
import { TwWrapperModule } from '../tw-wrapper/tw-wrapper.module';
import { TwcCustomComponent } from './twc-custom/twc-custom.component';
import { TwcHomeComponent } from './twc-home/twc-home.component';
import { TwcNoInteractionComponent } from './twc-no-interaction/twc-no-interaction.component';
import { TwcNoWidgetsComponent } from './twc-no-widgets/twc-no-widgets.component';
import { TwcSupervisorComponent } from './twc-supervisor/twc-supervisor.component';
import { TwcUnknownComponent } from './twc-unknown/twc-unknown.component';
import { TwcVoiceComponent } from './twc-voice/twc-voice.component';
import { TwcTextchatComponent } from './twc-textchat/twc-textchat.component';

@NgModule({
    declarations: [
        TwcUnknownComponent,
        TwcCustomComponent,
        TwcHomeComponent,
        TwcSupervisorComponent,
        TwcVoiceComponent,
        TwcNoWidgetsComponent,
        TwcNoInteractionComponent,
        TwcTextchatComponent,
    ],
    imports: [
        SharedModule,
        TwTemplateModule,
        TwWrapperModule
    ],
    exports: [
        TwcNoWidgetsComponent
    ]
})
export class TwContentModule { }
